package com.fdm.syncevent;


import java.util.Locale;

/*
 * Copyright (C) 2014 Federico Di Marco <fededim@gmail.com>
 *
 */

public interface ILogger {

	public void i(String format, Object ...params);
	public void i(Locale locale, String format, Object ...params);
	//public void i(String tag, String format, Object ...params);

	public void e(String format, Object ...params);
	public void e(Locale locale, String format, Object ...params);
	//public void e(String tag, String format, Object ...params);
	public void e(Exception e, String preformat, Object ...params);
	
	public void w(String format, Object ...params);
	public void w(Locale locale, String format, Object ...params);
	//public void w(String tag, String format, Object ...params);

	public void d(String format, Object ...params);
	public void d(Locale locale, String format, Object ...params);
	//public void d(String tag, String format, Object ...params);	
}
