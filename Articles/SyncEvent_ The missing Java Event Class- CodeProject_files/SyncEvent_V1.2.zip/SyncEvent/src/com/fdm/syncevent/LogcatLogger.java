package com.fdm.syncevent;

/*
 * Copyright (C) 2014 Federico Di Marco <fededim@gmail.com>
 *
 */

import java.util.Locale;


import android.util.Log;

public class LogcatLogger implements ILogger {
	String Tag;
	
	public LogcatLogger(String tag) {
		Tag=tag;
	}
	
	@Override
	public void i(String format, Object... params) {
		Log.i(Tag,String.format(Locale.US,format,params));
	}

	@Override
	public void e(String format, Object... params) {
		Log.e(Tag,String.format(Locale.US,format,params));
	}


	@Override
	public void w(String format, Object... params) {
		Log.w(Tag,String.format(Locale.US,format,params));
	}
	
	
	@Override
	public void d(String format, Object... params) {
		Log.d(Tag,String.format(Locale.US,format,params));
	}

	@Override
	public void e(Exception e, String preformat, Object... params) {
		Log.e(Tag,String.format(Locale.US,preformat,params));
		Log.e(Tag,e.toString());
	}

	@Override
	public void i(Locale locale, String format, Object... params) {
		Log.i(Tag,String.format(locale,format,params));		
	}

	@Override
	public void e(Locale locale, String format, Object... params) {
		Log.e(Tag,String.format(locale,format,params));			
	}

	@Override
	public void w(Locale locale, String format, Object... params) {
		Log.w(Tag,String.format(locale,format,params));			
	}

	@Override
	public void d(Locale locale, String format, Object... params) {
		Log.d(Tag,String.format(locale,format,params));			
	}
	
}
