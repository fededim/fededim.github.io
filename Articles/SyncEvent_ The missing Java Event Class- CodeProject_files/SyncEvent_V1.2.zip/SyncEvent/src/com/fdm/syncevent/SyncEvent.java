package com.fdm.syncevent;

import java.util.Queue;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import android.util.Pair;

public class SyncEvent {
    final static ILogger log = new LogcatLogger("SyncEvent");

    Object sync;
	boolean syncSignalled; 	//  the boolean is needed to save the status of signal notification, when the signal comes before the wait operation     
	String syncName;

	public SyncEvent(String name) {
		sync=new Object();
		syncSignalled=false;
		syncName=name;
	}
	
	
	/**
	* Gets the signal name specified during creation.
	* @return Returns the signal name used for logging.
	*/ 
	public String getName() {
		return syncName;
	}

	
	/**
	* Waits indefinetely for the event to be signalled. The signalled status of the event is auto-cleared on return.
	* @return <li>false</li> if the wait operation has been interrupted (someone is trying to "kill" our thread), <li>true</li> is the event has been signalled.
	*/ 
	public boolean waitForEvent() {
		return waitForEvent(true);
	}
		
	/**
	* Waits indefinetely for the event to be signalled. 
	* @param  autoclear	if true the signalled status of the event is auto-cleared on return. 
	* @return <li>false</li> if the wait operation has been interrupted (someone is trying to "kill" our thread), <li>true</li> is the event has been signalled.
	*/ 
	public boolean waitForEvent(boolean autoclear) {
		  synchronized (sync) {
			  	// while is needed since Java's wait function could return even when no signal has been raised (so called spurious wakeups)
			  	while (!syncSignalled) {
	  				//log.d("%s: Awaiting signal",syncName);
	  				try {
	  					sync.wait();
	  				}
	  				catch (InterruptedException e) {
		  				return false;	  				
	  				}
	  			}
	  			if (autoclear)
	  				syncSignalled=false;						
		  }
		  
		  return true;
	}
	
	
	/**
	* Waits for the event to be signalled up to the specified time. The signalled status is auto-cleared on return
	* @param  millis	maximum number of milliseconds to wait for 
	* @return 
	* <li>0</li> if the event has been signalled;
	* <li>-1</li> if the wait operation has been interrupted (someone is trying to "kill" our thread);
	* <li>-2</li> if the timeout has elapsed and the event has not been signalled
	*/ 	
	public int waitForEvent(long millis) {
		return waitForEvent(millis, true);
	}
	
	
	
	/**
	* Waits for the event to be signalled up to the specified time.
	* @param  millis	maximum number of milliseconds to wait for 
	* @param  autoclear	if true the signalled status of the event is auto-cleared on return. 
	* @return 
	* <li>0</li> if the event has been signalled;
	* <li>-1</li> if the wait operation has been interrupted (someone is trying to "kill" our thread);
	* <li>-2</li> if the timeout has elapsed and the event has not been signalled
	*/ 	
	public int waitForEvent(long millis, boolean autoclear) {		  		
		long startTime,elapsed;
		
		synchronized (sync) {
				// while is needed since Java's wait function could return even when no signal has been raised (so called spurious wakeups)
	  			while (!syncSignalled) {
	  				//log.d("%s: Awaiting signal",syncName);
	  				try {
	  					startTime=System.currentTimeMillis();
	  					sync.wait(millis);
	  					elapsed=System.currentTimeMillis()-startTime;
	  					if (elapsed>=millis)  // if it is a real timeout exit
	  						break;
	  					else
	  						millis-=elapsed;  // if it is a spurious wakeup go on waiting till the timeout has been reached
	  				}
	  				catch (InterruptedException e) {
		  				return -1;	  				
	  				}
	  			}
	  			boolean signal=syncSignalled;
	  			if (autoclear)
	  				syncSignalled=false;						
	  			return (signal?0:-2);
		  }
	}

	
	
	/**
	    * Waits for the first of multiple events to be signalled up to the specified time. 
	    * The signalled status of the first event is auto-cleared on return
	    * @param  millis    maximum number of milliseconds to wait for
	    * @param  events    an array of one or more events to wait concurrently for 
	    * @return 
	    * <li>i</li>  i>=0, if the i-th event has been signalled;
	    * <li>-1</li> if the wait operation has been interrupted 
	    * (someone is trying to "kill" our thread);
	    * <li>-2</li> if the timeout has elapsed and none of the events have been signalled
	    */          
	    public static int waitForMultipleEventsExecutor(final long millis, final SyncEvent ...events) {
	        int numEvents=events.length,ris=-1;                
	        
	        ExecutorService poolMultipleWait=Executors.newFixedThreadPool(numEvents);
	        ExecutorCompletionService<Pair<Integer,Integer>> 
	        cs=new ExecutorCompletionService<Pair<Integer,Integer>>(poolMultipleWait);
	        
	        // we launch multiple waits in parallel
	        for (int i=0;i<numEvents;i++) {
	            final int index=i;
	            cs.submit(new Callable<Pair<Integer,Integer>>() {
	                @Override
	                public Pair<Integer,Integer> call() throws Exception {
	                    return new Pair<Integer,Integer>(index,events[index].waitForEvent(millis,false));
	                }
	            });
	        }
	        
	        Pair<Integer, Integer> signalled;
	        try {
	            log.d("waitForMultipleEvents: awaiting on %d events %d timeout",numEvents,millis);
	            signalled = cs.take().get();
	            if (signalled.second==0)
	                ris=signalled.first;
	            else
	                ris=signalled.second;
	            events[signalled.first].resetEvent(); // we clear the event status
	            log.d("waitForMultipleEvents: received event %d (%s) result %d",signalled.first,events[signalled.first].syncName,signalled.second);
	        }
	        catch (InterruptedException e) {
	                ris=-1;  // we have been interrupted
	        }
	        catch (ExecutionException e) {
	            log.e(e,"waitForMultipleEvents: exception");
	        }
	        finally {
	            poolMultipleWait.shutdownNow();  // abort any other wait operation            
	        }        
	        
	        return ris;        
	    }    
	    
	/**
	* Waits for the first of multiple events to be signalled up to the specified time. The signalled status of the first event is auto-cleared on return
	* @param  millis	maximum number of milliseconds to wait for
	* @param  events	an array of one or more events to wait concurrently for 
	* @return 
	* <li>i</li>  i>=0, if the i-th event has been signalled;
	* <li>-1</li> if the wait operation has been interrupted (someone is trying to "kill" our thread);
	* <li>-2</li> if the timeout has elapsed and none of the events have been signalled
	*/ 	 	
	public static int waitForMultipleEvents (final long millis, final SyncEvent ...events) {
		int numEvents=events.length,ris=-1;				
		
		final SyncEvent eventQueueNotEmpty=new SyncEvent("eventQueueNotEmpty");
		final Queue<Pair<Integer,Integer>> eventQueue=new ConcurrentLinkedQueue<Pair<Integer,Integer>>();
		
		Thread [] poolMultipleWait=new Thread[numEvents];
		
		// we launch multiple waits in parallel
		for (int i=0;i<numEvents;i++) {
			final int index=i;
			poolMultipleWait[i]=new Thread() {
				
				@Override
				public void run() {
					eventQueue.add(new Pair<Integer,Integer>(index,events[index].waitForEvent(false)?0:-1));
					eventQueueNotEmpty.signalEvent();
					//log.d("waitForMultipleEvents: thread waiting on event %s exiting...",events[index].getName());
				}
			};
			poolMultipleWait[i].start();
		}
					
		
		log.d("waitForMultipleEvents: awaiting on %d events %d timeout (ActiveThreads %d)",numEvents,millis,Thread.activeCount());
		ris=eventQueueNotEmpty.waitForEvent(millis);
		
		// abort any other wait operation
		for (int i=0;i<numEvents;i++)
			if (poolMultipleWait[i].isAlive())
				poolMultipleWait[i].interrupt();			
		
		// if we have been signalled 
		if (ris==0) {		
			// check the "first" signalled event
			Pair<Integer, Integer> signalled = eventQueue.peek();
			if (signalled.second==0) {
				ris=signalled.first;
				events[signalled.first].resetEvent(); // we clear the event status
			}
			else
				ris=signalled.second;
	
			log.d("waitForMultipleEvents: received event %d (%s) result %d",signalled.first,events[signalled.first].syncName,signalled.second);
		}
		
		return ris;		
	}
	
	

	
	/**
	* Waits indefinitely for the first of multiple events to be signalled. The signalled status of the first event is auto-cleared on return
	* @param	events	an array of one or more events to wait concurrently for 
	* @return
	* <li>i</li> i>=0, if the i-th event has been signalled;
	* <li>-1</li> if the wait operation has been interrupted (someone is trying to "kill" our thread);
	*/ 	 	
	public static int waitForMultipleEvents (final SyncEvent ...events) {
		int numEvents=events.length,ris=-1;				
		
		final SyncEvent eventQueueNotEmpty=new SyncEvent("eventQueueNotEmpty");
		final Queue<Pair<Integer,Integer>> eventQueue=new ConcurrentLinkedQueue<Pair<Integer,Integer>>();
		
		Thread [] poolMultipleWait=new Thread[numEvents];
		
		// we launch multiple waits in parallel
		for (int i=0;i<numEvents;i++) {
			final int index=i;
			poolMultipleWait[i]=new Thread() {
				
				@Override
				public void run() {
					eventQueue.add(new Pair<Integer,Integer>(index,events[index].waitForEvent(false)?0:-1));
					eventQueueNotEmpty.signalEvent();
					//log.d("waitForMultipleEvents: thread waiting on event %s exiting...",events[index].getName());
				}
			};
			poolMultipleWait[i].start();
		}
					
		
		log.d("waitForMultipleEvents: awaiting on %d events (ActiveThreads %d)",numEvents,Thread.activeCount());
		ris=eventQueueNotEmpty.waitForEvent()?0:-1;

		// abort any other wait operation
		for (int i=0;i<numEvents;i++)
			if (poolMultipleWait[i].isAlive())
				poolMultipleWait[i].interrupt();			

		// if we have been signalled
		if (ris==0) {		
			// check the "first" signalled event
			Pair<Integer, Integer> signalled = eventQueue.peek();
			if (signalled.second==0) {
				ris=signalled.first;
				events[signalled.first].resetEvent(); // we clear the event status
			}
			else
				ris=signalled.second;

			log.d("waitForMultipleEvents: received event %d (%s) result %d",signalled.first,events[signalled.first].syncName,signalled.second);
		}
		
		return ris;		
	}
	
	
	/**
	* Waits indefinitely for the first of multiple events to be signalled. The signalled status of the first event is auto-cleared on return
	* @param	events	an array of one or more events to wait concurrently for 
	* @return
	* <li>i</li> i>=0, if the i-th event has been signalled;
	* <li>-1</li> if the wait operation has been interrupted (someone is trying to "kill" our thread);
	*/ 	 	
	public static int waitForMultipleEventsExecutor (final SyncEvent ...events) {
		int numEvents=events.length,ris=-1;
				
		ExecutorService poolMultipleWait=Executors.newFixedThreadPool(numEvents);
		ExecutorCompletionService<Pair<Integer,Boolean>> cs=new ExecutorCompletionService<Pair<Integer,Boolean>>(poolMultipleWait);
				
		// we launch multiple waits in parallel
		for (int i=0;i<numEvents;i++) {
			final int index=i;
			cs.submit(new Callable<Pair<Integer,Boolean>>() {
				@Override
				public Pair<Integer,Boolean> call() throws Exception {
					return new Pair<Integer,Boolean>(index,events[index].waitForEvent(false));
				}
			});
		}
		
		Pair<Integer, Boolean> signalled;
		try {
			log.d("waitForMultipleEvents: awaiting on %d events",numEvents);
			signalled = cs.take().get();
			if (signalled.second)
				ris=signalled.first;
			events[signalled.first].resetEvent(); // we clear the event status
			log.d("waitForMultipleEvents: received event %d (%s) result %b",signalled.first,events[signalled.first].getName(),signalled.second);
		}
		catch (InterruptedException e) {
			ris=-1;
		}
		catch (ExecutionException e) {
			log.e(e,"waitForMultipleEvents: exception");
		}
		finally {
			poolMultipleWait.shutdownNow();  // abort any other wait operation			
		}
		
		return ris;		
	}

	
	
	/**
	* Checks if the event has been signalled. The signal status is auto-cleared on return.
	* @return <li>true</li> if the event has been signalled;
	* <li>false</li>	otherwise 
	*/ 	
	public boolean isSignalled () {
		return isSignalled(true);
	}
	
	

	
	/**
	* Checks if the event has been signalled.
	* @param  autoclear	if true the signalled status of the event is auto-cleared on return. 
	* @return <li>true</li> if the event has been signalled;
	* <li>false</li>	otherwise 
	*/ 	
	public boolean isSignalled (boolean autoclear) {
		synchronized (sync) {
			boolean ris=syncSignalled;
			if (autoclear)
				syncSignalled=false;
			return ris;
		}
	}

	
	
	
	/**
	* Signals the event, waking one of the threads waiting on the signal (can be more than one).
	*/ 	
	public void signalEvent() {
		  synchronized (sync) {
			syncSignalled=true;
			sync.notify();
		  }
	}
	
	
	/**
	* Clears manually the signalled status of the event.
	*/ 	
	public void resetEvent() {
		  synchronized (sync) {
			syncSignalled=false;
		  }		
	}
}
