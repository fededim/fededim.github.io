package com.fdm.syncevent;

import android.support.v7.app.ActionBarActivity;
import android.content.Context;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends ActionBarActivity implements OnClickListener {
	SyncEvent []events=new SyncEvent[] { new SyncEvent("start"), new SyncEvent("stop")};

	ILogger log=new LogcatLogger("MainActivity");
	
	Thread t;

	Button startBtn,abortBtn;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_main);			

		startBtn=(Button) findViewById(R.id.startBtn);
		abortBtn=(Button) findViewById(R.id.abortBtn);
		
		startBtn.setOnClickListener(this);
		abortBtn.setOnClickListener(this);	
	}

		
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}


	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}


	@Override
	public void onClick(View v) {
		switch (v.getId()) {
			case R.id.startBtn:
				// Create Thread 1
				if (t==null) {
					t=new Thread() {
						public void run() {
			
							log.i("Thread 1 started");
							while (true) {
								log.i("Awaiting start or stop signal from another thread");
								int ris=SyncEvent.waitForMultipleEvents(5000,events);
								if (ris==-1) {
									log.i("Thread 1 abort signal received");
									break;
								}
								else if (ris>=0)
									log.i("Thread 1 %s event received, processing...",events[ris].getName());
								else
									log.i("Thread 1 timeout elapsed, restarting...");
							}
							log.i("Thread 1 exiting");
							t=null;
						};
					};
					t.start();
				}
				else {
					int offset=(int) (System.currentTimeMillis()%2);
					log.i("Signalling %s to thread 1",events[offset].getName());
					events[offset].signalEvent();
			}

			break;
			
			case R.id.abortBtn:
				log.i("Signalling abort to thread 1");
				if (t!=null)
					t.interrupt();
			break;		
		}
	}
}
